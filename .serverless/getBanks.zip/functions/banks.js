exports.getBanks = async (event) => {
    return {
        banks: [
            {
                id: 1,
                name: "OrbitBank"
            }
        ]
    }
}